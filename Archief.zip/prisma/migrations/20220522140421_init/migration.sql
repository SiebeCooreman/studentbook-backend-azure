-- AlterTable
ALTER TABLE `Message` MODIFY `text` VARCHAR(256) NOT NULL;
