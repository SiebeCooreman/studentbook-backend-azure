const { PrismaClient } = require('@prisma/client');

const db = new PrismaClient();

export = { db };
